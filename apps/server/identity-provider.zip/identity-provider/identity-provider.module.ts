import { DynamicModule, Global, Module } from "@nestjs/common";
import { getIdentityProvider } from "./providers";

@Global()
@Module({})
export class IdentityProviderModule {
  static forRoot(provider: string): DynamicModule {
    const services = getIdentityProvider(provider);
    return {
      module: IdentityProviderModule,
      providers: services,
      exports: services,
    };
  }
}
