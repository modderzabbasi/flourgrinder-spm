import constants from "../constants";
import FirebaseIdentityService from "./firebase/firebase.service";
import MockIdentityService from "./mock/mock.service";

export const providers = [
  {
    provide: constants.IDENTITY_PROVIDER_FIREBASE,
    useClass: FirebaseIdentityService,
  },
  {
    provide: constants.IDENTITY_PROVIDER_MOCK,
    useClass: MockIdentityService,
  },
];

export function getIdentityProvider(provider: string) {
  let identityProvider = providers.find((p) => p.provide === provider);

  if (!identityProvider) {
    identityProvider = providers.find(
      (p) => p.provide === constants.IDENTITY_PROVIDER_MOCK
    );
  }

  return [
    {
      ...identityProvider,
      ...{ provide: constants.IDENTITY_PROVIDER_SERVICE },
    },
  ];
}
