import { Injectable, Logger } from "@nestjs/common";
import * as admin from "firebase-admin";
import { auth } from "firebase-admin";
import { UserRecord } from "firebase-admin/auth";
import { ICreateUserRequest, IIdpUser, IUpdateUserRequest } from "../../types";

@Injectable()
class FirebaseIdentityService {
  private readonly authInstance: auth.Auth;

  private readonly logger: Logger = new Logger(FirebaseIdentityService.name);

  constructor() {
    if (!admin.apps.length) {
      const app = admin.initializeApp();

      this.authInstance = admin.auth(app);
    }
  }

  async createUser({
    email,
    password,
    phone,
    emailVerified = true,
    claims,
  }: ICreateUserRequest): Promise<IIdpUser> {
    const userRecord = await this.authInstance.createUser({
      email,
      password,
      phoneNumber: phone,
      emailVerified,
    });
    await this.authInstance.setCustomUserClaims(userRecord.uid, claims);

    return {
      id: userRecord.uid,
      email,
      claims,
      isEnabled: !userRecord.disabled,
    };
  }

  convertUserRecordToUser(userRecord: UserRecord) {
    return {
      id: userRecord.uid,
      email: userRecord.email ?? "",
      isEnabled: !userRecord.disabled,
      claims: userRecord.customClaims ? userRecord.customClaims : {},
    };
  }

  async getUserById(id: string): Promise<IIdpUser | null> {
    const userRecord = await this.authInstance.getUser(id);

    if (userRecord == null) {
      return null;
    }

    return this.convertUserRecordToUser(userRecord) as IIdpUser;
  }

  async getUserByEmail(email: string): Promise<IIdpUser | null> {
    try {
      const userRecord = await this.authInstance.getUserByEmail(email);
      return this.convertUserRecordToUser(userRecord) as IIdpUser;
    } catch (err) {
      return null;
    }
  }

  async updateUser(id: string, request: IUpdateUserRequest): Promise<void> {
    const disabled = request.isEnabled != null ? !request.isEnabled : undefined;
    await this.authInstance.updateUser(id, {
      email: request.email ?? undefined,
      password: request.password ?? undefined,
      disabled,
    });
    if (request.claims != null) {
      await this.authInstance.setCustomUserClaims(id, request.claims);
    }
  }

  async verifyIDToken(token: string) {
    try {
      if (!token) return null;
      const decodedToken = await this.authInstance.verifyIdToken(token);
      return {
        uid: decodedToken.uid,
        permissions: {
          admin: decodedToken.admin,
          cs: decodedToken.cs,
        },
      };
    } catch (err) {
      this.logger.error(err);
      throw err;
    }
  }

  // Generate password reset email link
  async generatePasswordResetEmailLink(email: string) {
    try {
      const userRecord = await this.authInstance.getUserByEmail(email);
      if (!userRecord) {
        throw new Error("User not found");
      }
      const url = await this.authInstance.generatePasswordResetLink(
        userRecord.email
      );
      return url;
    } catch (error) {
      this.logger.error(error);
      throw error;
    }
  }

  // Generate Email Verification Link
  async generateEmailVerificationLink(email: string) {
    try {
      const userRecord = await this.authInstance.getUserByEmail(email);
      if (!userRecord) {
        throw new Error("User not found");
      }
      const url = await this.authInstance.generateEmailVerificationLink(
        userRecord.email
      );
      return url;
    } catch (error) {
      this.logger.error(error);
      throw error;
    }
  }
}

export default FirebaseIdentityService;
