import { v4 as uuid } from "uuid";
import { ICreateUserRequest, IIdpUser, IUpdateUserRequest } from "../../types";

class MockIdentityService {
  private readonly users: IIdpUser[] = [];

  private readonly userPasswords = new Map<IIdpUser, string>();

  async createUser(request: ICreateUserRequest): Promise<IIdpUser> {
    const id = uuid();

    const user: IIdpUser = {
      id,
      email: request.email,
      isEnabled: true,
    };

    this.users.push(user);

    this.userPasswords.set(user, request.password);

    return user;
  }

  private getUserByIdSync(id: string): IIdpUser | null {
    const user = this.users.find((x) => x.id === id);

    if (user == null) {
      return null;
    }

    return { ...user };
  }

  getUserById(id: string): Promise<IIdpUser | null> {
    return Promise.resolve(this.getUserByIdSync(id));
  }

  async updateUser(id: string, request: IUpdateUserRequest): Promise<void> {
    const user = this.users.find((x) => x.id === id);

    if (user == null) {
      throw new Error(`User with id '${id}' not found.`);
    }

    if (request.email != null) {
      user.email = request.email;
    }

    if (request.password != null) {
      this.userPasswords.set(user, request.password);
    }

    if (request.isEnabled != null) {
      user.isEnabled = request.isEnabled;
    }
  }

  async getUserByLogin(email: string): Promise<IIdpUser | null> {
    const user = this.users.find((x) => x.email === email);

    if (user == null) {
      return null;
    }

    return { ...user };
  }
}

export default MockIdentityService;
