export interface IClaims {
  cs?: string[];
  admin?: string[];
}

export interface ICreateUserRequest {
  email: string;
  password: string;
  phone: string;
  emailVerified?: boolean;
  claims: IClaims;
}

export interface IIdpUser {
  id: string;
  email: string;
  claims?: IClaims;
  isEnabled: boolean;
}

export interface IUpdateUserRequest {
  email?: string | null;
  password?: string | null;
  claims?: IClaims | null;
  isEnabled?: boolean;
}

export interface IIdentityProviderService {
  createUser(request: ICreateUserRequest): Promise<IIdpUser>;
  getUserById(id: string): Promise<IIdpUser | null>;
  getUserByEmail(email: string): Promise<IIdpUser | null>;
  updateUser(id: string, request: IUpdateUserRequest): Promise<void>;
  verifyIDToken(token: string): Promise<{ uid: string; permissions: string[] }>;
  generatePasswordResetEmailLink(email: string): Promise<string>;
  generateEmailVerificationLink(email: string): Promise<string>;
}
